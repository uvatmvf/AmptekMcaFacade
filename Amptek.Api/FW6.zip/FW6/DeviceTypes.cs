﻿using System;
using System.Collections.Generic;
using System.Text;

namespace csRepeat
{
    public enum DeviceTypes
    {
        DP5 = 0,
        PX5 = 1,
        DP5G = 2,
        MCA8000D = 3,
        TB5 = 4,
        ANY
    };
}
